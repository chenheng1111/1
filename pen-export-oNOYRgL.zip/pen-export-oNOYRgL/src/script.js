document.write("HELLO我是chen heng ")
